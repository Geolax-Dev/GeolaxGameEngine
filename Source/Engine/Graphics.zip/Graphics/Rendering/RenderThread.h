#pragma once

#include <Core/Event/Event.h>
#include <Core/ThreadPool.h>

#include <bgfx/bgfx.h>
#include <bgfx/platform.h>

namespace GGE
{
    class Window;
    class BgfxCallback;

    enum RenderingViews
    {
        RenderingViews_Clear = 0,   // For clear color
        RenderingViews_Main = 10,   // For main rendering (triangle for now)
    };

    class RenderThread
    {
    public:
        RenderThread() = default;
        ~RenderThread();

        // ![gets called from main thread]
        bool Startup(const std::shared_ptr<Window>& window);

        // ![gets called from main thread]
        void Shutdown();

        // ![gets called from main thread]
        void ResizeSwapchain(uint32 width, uint32 height);

        void BeginFrame();
        void EndFrame();

        [[maybe_unused]] LockedObject<GraphicsEventSubscribers> GetEventSubscribers(GraphicsEventSubscribers& es)
        {
            es = m_eventSubscribers;
            return { m_eventSubscribers, m_eventSubscribersMutex };
        }
    private:
        std::atomic_bool m_initialized{ false };
        std::atomic_bool m_initFailed{ false };
        std::atomic_bool m_running{ false };

        std::binary_semaphore m_initSemaphore{ 0 };
        
        std::unique_ptr<std::thread> m_thread{};

        std::shared_ptr<Window> m_window{};

        std::atomic_bool m_resizeRequested{};
        std::binary_semaphore m_resizeHandledSemaphore{ 0 };
        uint32 m_framebufferWidth{}, m_framebufferHeight{};

        GraphicsEventSubscribers m_eventSubscribers{};
        std::mutex m_eventSubscribersMutex{};

        BgfxCallback* m_bgfxCb{};

        void NotifyEvents(const GraphicsEvent&);

        RenderThread(const RenderThread&);
        RenderThread(RenderThread&&) noexcept;
        void renderThreadMain(const std::shared_ptr<Window>&);
    };

}
