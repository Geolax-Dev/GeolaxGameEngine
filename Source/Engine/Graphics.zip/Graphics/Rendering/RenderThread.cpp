#include "RenderThread.h"

#include <Core/Window.h>
#include <Core/Event/GraphicsEvents.h>

#include <Graphics/Tools/BgfxCallback.h>

#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>

GGE::RenderThread::~RenderThread()
{
    if (m_initialized)
        Shutdown();
}

bool GGE::RenderThread::Startup(const std::shared_ptr<Window>& window)
{
    m_window = window;
    m_framebufferWidth = m_window->GetWidth();
    m_framebufferHeight = m_window->GetHeight();
    m_initFailed = false;
    m_initialized = false;
    m_running = true;

    m_bgfxCb = new BgfxCallback();

    {
        bgfx::PlatformData platformData{};
        platformData.nwh = glfwGetWin32Window(m_window->GetGLFW());

        bgfx::Init init{};
        init.type = bgfx::RendererType::Direct3D11;
        init.resolution.width = m_window->GetWidth();
        init.resolution.height = m_window->GetHeight();
        uint32 resetFlags = BGFX_RESET_SRGB_BACKBUFFER;
        resetFlags |= (!m_window->IsVSync()) ? 0u : BGFX_RESET_VSYNC;
        resetFlags |= (!m_window->IsFullscreen()) ? 0u : BGFX_RESET_FULLSCREEN;
        init.resolution.reset = resetFlags;
        init.resolution.numBackBuffers = m_window->IsTrippleBuffering() ? 3 : 2;
        init.capabilities = 0
            | BGFX_CAPS_COMPUTE
            | BGFX_CAPS_DRAW_INDIRECT
            | BGFX_CAPS_DRAW_INDIRECT_COUNT
            | BGFX_CAPS_INSTANCING
            | BGFX_CAPS_OCCLUSION_QUERY
            | BGFX_CAPS_RENDERER_MULTITHREADED
            | BGFX_CAPS_TEXTURE_2D_ARRAY
            ;
        init.debug = !DISTRIBUTION_READY;
        init.profile = false; // TODO: make profiling configurable externally!
        init.platformData = platformData;
        init.callback = m_bgfxCb;
        GGE_ASSERT(bgfx::init(init));
    }

    bgfx::setDebug(BGFX_DEBUG_TEXT);

    bgfx::setViewName(RenderingViews_Clear, "Clear");
    bgfx::setViewName(RenderingViews_Main, "Main");

    bgfx::setViewMode(RenderingViews_Clear, bgfx::ViewMode::Sequential);      // just clears
    bgfx::setViewMode(RenderingViews_Main, bgfx::ViewMode::Default);         // state/material friendly

    m_thread = std::make_unique<std::thread>(
        [this, window] { renderThreadMain(window); }
    );

    m_initSemaphore.acquire();

    return m_initialized.load() && !m_initFailed;
}

void GGE::RenderThread::Shutdown()
{
    m_running = false;

    if (m_thread && m_thread->joinable())
        m_thread->join();

    bgfx::shutdown();

    m_initialized = false;
}

void GGE::RenderThread::ResizeSwapchain(uint32 width, uint32 height)
{
    m_resizeRequested = true;
}

void GGE::RenderThread::BeginFrame()
{
    if (m_resizeRequested)
    {
        uint32 resetFlags = BGFX_RESET_SRGB_BACKBUFFER;
        resetFlags |= (!m_window->IsVSync()) ? 0u : BGFX_RESET_VSYNC;
        resetFlags |= (!m_window->IsFullscreen()) ? 0u : BGFX_RESET_FULLSCREEN;
        int w, h;
        glfwGetFramebufferSize(m_window->GetGLFW(), &w, &h);
        m_framebufferWidth = w;
        m_framebufferHeight = h;

        bgfx::reset(m_framebufferWidth, m_framebufferHeight, resetFlags);

        m_resizeHandledSemaphore.release();
    }

    bgfx::setViewRect(RenderingViews_Clear, 0, 0, (uint16)m_framebufferWidth, (uint16)m_framebufferHeight);
    bgfx::setViewRect(RenderingViews_Main, 0, 0, (uint16)m_framebufferWidth, (uint16)m_framebufferHeight);

    bgfx::setViewClear(RenderingViews_Clear, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0x1d1e28ff);

    bgfx::touch(RenderingViews_Clear);

}

void GGE::RenderThread::EndFrame()
{
    Sleep(1);

    bgfx::frame();
}

void GGE::RenderThread::NotifyEvents(const GraphicsEvent& ev)
{
    GraphicsEventSubscribers es;
    auto locker = GetEventSubscribers(es);
    es.NotifyAll(const_cast<GraphicsEvent&>(ev));
}

void GGE::RenderThread::renderThreadMain(const std::shared_ptr<Window>& window)
{
    NotifyEvents(RenderThreadSpawnedEvent());

    bool bSuccess = true;

    // doing rendering initialization with bgfx, spawning workers, etc..

    m_initialized = bSuccess;
    m_initFailed = !bSuccess;
    m_initSemaphore.release();

    if (!bSuccess)
    {
        NotifyEvents(RenderThreadStoppedEvent());
        return;
    }

    NotifyEvents(RenderThreadInitializedEvent());

    while (m_running.load(std::memory_order_relaxed)) {
        if (m_resizeRequested)
        {
            m_resizeHandledSemaphore.acquire();
            m_resizeRequested = false;
        }

        
        if (bgfx::Encoder* enc = bgfx::begin())
        {
            
            bgfx::end(enc);
        }

        bgfx::renderFrame();
    }

    NotifyEvents(RenderThreadStoppedEvent());
}
