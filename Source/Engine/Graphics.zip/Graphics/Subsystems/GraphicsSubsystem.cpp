#include "GraphicsSubsystem.h"

#include <Core/Window.h>
#include <Graphics/Rendering/RenderThread.h>

namespace GGE
{
    std::shared_ptr<Window> GraphicsSubsystem::s_CurrentWindow = {};
}

void GGE::GraphicsSubsystem::OnResize(uint32 width, uint32 height)
{
    m_renderThread->ResizeSwapchain(width, height);
}

void GGE::GraphicsSubsystem::OnDisableRendering(bool disable)
{
    if (disable)
    {
        GGE_LOG_DEBUG("Rendering disabled!");
    }
}

bool GGE::GraphicsSubsystem::OnCreateSubsystem()
{
    return true;
}

bool GGE::GraphicsSubsystem::OnPostCreateSubsystem()
{
    GGE_LOG_INFO("Creating Graphics Subsystem...");

    bool bSuccess = true;

    m_renderThread = std::make_unique<RenderThread>();
    bSuccess &= m_renderThread->Startup(s_CurrentWindow);

    s_CurrentWindow->GetEventSubscribers() += [this](WindowEvent& wevent)
        {
            if (wevent.GetEventType() == WindowEvents_WindowResize)
            {
                const WindowResizeEvent& resizeEvent = static_cast<const WindowResizeEvent&>(wevent);
                GGE_LOG_INFO("Window resized to {}x{}", resizeEvent.width, resizeEvent.height);

                const bool disabledRendering = (resizeEvent.width == 0) || (resizeEvent.height == 0);
                OnDisableRendering(disabledRendering);

                if (!disabledRendering)
                {
                    OnResize(resizeEvent.width, resizeEvent.height);
                }
            }
        };

    if (bSuccess)
    {
        GGE_LOG_INFO("Graphics Subsystem created successfully");
    }
    else
    {
        GGE_LOG_ERROR("Failed to create Graphics Subsystem");
    }

    return bSuccess;
}

bool GGE::GraphicsSubsystem::OnUpdateSubsystem()
{
    m_renderThread->BeginFrame();
    // TODO: fill renderdata!
    m_renderThread->EndFrame();
    return true;
}

void GGE::GraphicsSubsystem::OnDestroySubsystem()
{
    GGE_LOG_INFO("Destroying Graphics Subsystem...");

    m_renderThread->Shutdown();
    m_renderThread.reset();

}

void GGE::GraphicsSubsystem::SetCurrentWindow(std::shared_ptr<Window> w)
{
    s_CurrentWindow = w;
}

std::shared_ptr<GGE::Window> GGE::GraphicsSubsystem::GetCurrentWindow()
{
    return s_CurrentWindow;
}
