#pragma once

#include <Core/Subsystems/ISubsystem.h>
#include <Graphics/Rendering/RenderThread.h>

namespace GGE
{
    class Window; // Forward declaration

    class GraphicsSubsystem : public ISubsystem
    {
    public:
        GraphicsSubsystem() = default;
        ~GraphicsSubsystem() override = default;

        bool OnCreateSubsystem() override;
        bool OnPostCreateSubsystem() override;
        bool OnUpdateSubsystem() override;
        void OnDestroySubsystem() override;

        static void SetCurrentWindow(std::shared_ptr<Window>);
        static std::shared_ptr<Window> GetCurrentWindow();

    private:
        void OnResize(uint32 width, uint32 height);
        void OnDisableRendering(bool disable);

    private:
        std::unique_ptr<RenderThread> m_renderThread;

        static std::shared_ptr<Window> s_CurrentWindow;
    };
}
